import { createBrowserRouter } from "react-router";
import { LandingPage } from "@/app/components/LandingPage";
import { CategoryPage } from "@/app/components/CategoryPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/categories",
    Component: CategoryPage,
  },
]);
