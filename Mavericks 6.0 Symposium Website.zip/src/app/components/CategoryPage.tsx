import { motion } from 'motion/react';
import { Cpu, Users } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';
import mavericksLogo from 'figma:asset/83de7bba450a0de2c7cc43f40179f92ea2cfaf64.png';

export function CategoryPage() {
  const handleTechnicalRegister = () => {
    window.open('https://forms.google.com', '_blank');
  };

  const handleNonTechnicalRegister = () => {
    window.open('https://forms.google.com', '_blank');
  };

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1735713212083-82eafc42bf64?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwdGVjaCUyMGNpcmN1aXQlMjBib2FyZCUyMGJsdWV8ZW58MXx8fHwxNzcwMTI2MjYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Tech background"
          className="w-full h-full object-cover opacity-15"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-black/80 to-black/90" />
      </div>

      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-5">
        <div className="h-full w-full"
          style={{
            backgroundImage: `linear-gradient(#00ffff 1px, transparent 1px), linear-gradient(90deg, #00ffff 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Logo Watermark - More Visible */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center opacity-15 pointer-events-none p-8"
        animate={{
          rotate: [0, 3, 0, -3, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{
          filter: 'drop-shadow(0 0 40px rgba(0, 255, 255, 0.3))',
        }}
      >
        <img 
          src={mavericksLogo} 
          alt="Mavericks 6.0 Logo" 
          className="w-full h-full object-contain max-w-4xl max-h-screen"
        />
      </motion.div>

      {/* Floating Particles */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-cyan-400 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -40, 0],
            x: [0, Math.random() * 20 - 10, 0],
            opacity: [0.2, 1, 0.2],
          }}
          transition={{
            duration: 4 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
          }}
        />
      ))}

      {/* Circuit Lines */}
      <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
        <motion.path
          d="M0 200 L 200 200 L 200 400 L 400 400"
          stroke="#00ffff"
          strokeWidth="2"
          fill="none"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        />
        <motion.path
          d="M1200 100 L 1000 100 L 1000 300 L 800 300"
          stroke="#ff0055"
          strokeWidth="2"
          fill="none"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 3, delay: 1, repeat: Infinity, ease: "linear" }}
        />
      </svg>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col px-4 py-12">
        {/* Top Logo */}
        <motion.div
          className="flex justify-center pt-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.img
            src={mavericksLogo}
            alt="Mavericks Logo"
            className="w-16 h-16 md:w-20 md:h-20 object-contain"
            animate={{
              filter: [
                'drop-shadow(0 0 15px rgba(0, 255, 255, 0.5))',
                'drop-shadow(0 0 25px rgba(0, 255, 255, 0.8))',
                'drop-shadow(0 0 15px rgba(0, 255, 255, 0.5))',
              ],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
            }}
          />
        </motion.div>

        <div className="flex-1 flex items-center justify-center">
          <motion.div
            className="text-center space-y-12 max-w-6xl w-full"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Simple Description */}
            <motion.div
              className="space-y-3"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
                Choose your path and register for the events that match your passion
              </p>
            </motion.div>

            {/* Event Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 mt-16">
              {/* Technical Events Card */}
              <motion.div
                className="relative group"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                whileHover={{ scale: 1.02 }}
              >
                <div className="relative bg-gradient-to-br from-gray-900 to-black border-2 border-cyan-500/50 rounded-2xl p-8 md:p-10 overflow-hidden shadow-2xl">
                  {/* Card Glow Effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  />
                  
                  {/* Animated Border Glow */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl"
                    animate={{
                      boxShadow: [
                        '0 0 20px rgba(0, 255, 255, 0.3)',
                        '0 0 40px rgba(0, 255, 255, 0.6)',
                        '0 0 20px rgba(0, 255, 255, 0.3)',
                      ],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                    }}
                  />

                  <div className="relative z-10 space-y-6">
                    {/* Icon */}
                    <motion.div
                      className="inline-block"
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/50">
                        <Cpu className="w-8 h-8 md:w-10 md:h-10 text-white" />
                      </div>
                    </motion.div>

                    {/* Title */}
                    <h2 className="text-3xl md:text-4xl font-bold text-cyan-400">
                      Technical Events
                    </h2>

                    {/* Description */}
                    <p className="text-base md:text-lg text-gray-300 leading-relaxed min-h-[4rem]">
                      Participate in innovative technical challenges showcasing engineering and problem-solving skills.
                    </p>

                    {/* Features */}
                    <div className="flex flex-wrap gap-2 pt-4">
                      {['Coding', 'Robotics', 'AI/ML', 'IoT'].map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 text-sm bg-cyan-500/20 text-cyan-300 rounded-full border border-cyan-500/30"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Register Button */}
                    <motion.button
                      onClick={handleTechnicalRegister}
                      className="w-full mt-6 px-8 py-4 text-lg font-bold text-white bg-gradient-to-r from-cyan-600 to-blue-600 rounded-xl relative overflow-hidden group"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <span className="relative z-10">REGISTER NOW</span>
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-400 opacity-0 group-hover:opacity-50 transition-opacity"
                      />
                    </motion.button>
                  </div>

                  {/* Decorative Corner */}
                  <div className="absolute top-0 right-0 w-24 h-24 border-t-2 border-r-2 border-cyan-500/30" />
                  <div className="absolute bottom-0 left-0 w-24 h-24 border-b-2 border-l-2 border-cyan-500/30" />
                </div>

                {/* Card Shadow Glow */}
                <div className="absolute inset-0 bg-cyan-500/20 rounded-2xl blur-2xl -z-10 opacity-50 group-hover:opacity-100 transition-opacity" />
              </motion.div>

              {/* Non-Technical Events Card */}
              <motion.div
                className="relative group"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                whileHover={{ scale: 1.02 }}
              >
                <div className="relative bg-gradient-to-br from-gray-900 to-black border-2 border-red-500/50 rounded-2xl p-8 md:p-10 overflow-hidden shadow-2xl">
                  {/* Card Glow Effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  />
                  
                  {/* Animated Border Glow */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl"
                    animate={{
                      boxShadow: [
                        '0 0 20px rgba(239, 68, 68, 0.3)',
                        '0 0 40px rgba(239, 68, 68, 0.6)',
                        '0 0 20px rgba(239, 68, 68, 0.3)',
                      ],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: 0.5,
                    }}
                  />

                  <div className="relative z-10 space-y-6">
                    {/* Icon */}
                    <motion.div
                      className="inline-block"
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-red-500/50">
                        <Users className="w-8 h-8 md:w-10 md:h-10 text-white" />
                      </div>
                    </motion.div>

                    {/* Title */}
                    <h2 className="text-3xl md:text-4xl font-bold text-red-400">
                      Non-Technical Events
                    </h2>

                    {/* Description */}
                    <p className="text-base md:text-lg text-gray-300 leading-relaxed min-h-[4rem]">
                      Fun, creativity and team-based events designed to test talent beyond technology.
                    </p>

                    {/* Features */}
                    <div className="flex flex-wrap gap-2 pt-4">
                      {['Gaming', 'Arts', 'Sports', 'Quiz'].map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 text-sm bg-red-500/20 text-red-300 rounded-full border border-red-500/30"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Register Button */}
                    <motion.button
                      onClick={handleNonTechnicalRegister}
                      className="w-full mt-6 px-8 py-4 text-lg font-bold text-white bg-gradient-to-r from-red-600 to-pink-600 rounded-xl relative overflow-hidden group"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <span className="relative z-10">REGISTER NOW</span>
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-red-400 to-pink-400 opacity-0 group-hover:opacity-50 transition-opacity"
                      />
                    </motion.button>
                  </div>

                  {/* Decorative Corner */}
                  <div className="absolute top-0 right-0 w-24 h-24 border-t-2 border-r-2 border-red-500/30" />
                  <div className="absolute bottom-0 left-0 w-24 h-24 border-b-2 border-l-2 border-red-500/30" />
                </div>

                {/* Card Shadow Glow */}
                <div className="absolute inset-0 bg-red-500/20 rounded-2xl blur-2xl -z-10 opacity-50 group-hover:opacity-100 transition-opacity" />
              </motion.div>
            </div>

            {/* Back Navigation */}
            <motion.div
              className="pt-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <a
                href="/"
                className="inline-block text-gray-400 hover:text-cyan-400 transition-colors"
              >
                ← Back to Home
              </a>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Corner Accents */}
      <div className="absolute top-0 left-0 w-32 h-32 border-t-2 border-l-2 border-cyan-500/50" />
      <div className="absolute top-0 right-0 w-32 h-32 border-t-2 border-r-2 border-red-500/50" />
      <div className="absolute bottom-0 left-0 w-32 h-32 border-b-2 border-l-2 border-cyan-500/50" />
      <div className="absolute bottom-0 right-0 w-32 h-32 border-b-2 border-r-2 border-red-500/50" />
    </div>
  );
}