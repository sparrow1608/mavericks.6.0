import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';
import mavericksLogo from 'figma:asset/83de7bba450a0de2c7cc43f40179f92ea2cfaf64.png';

export function LandingPage() {
  const navigate = useNavigate();
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const targetDate = new Date('2026-02-14T10:00:00');

    const updateCountdown = () => {
      const now = new Date();
      const difference = targetDate.getTime() - now.getTime();

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1735713212083-82eafc42bf64?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwdGVjaCUyMGNpcmN1aXQlMjBib2FyZCUyMGJsdWV8ZW58MXx8fHwxNzcwMTI2MjYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Tech background"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/80" />
      </div>

      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-5">
        <div className="h-full w-full"
          style={{
            backgroundImage: `linear-gradient(#00ffff 1px, transparent 1px), linear-gradient(90deg, #00ffff 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Large Logo Watermark - More Visible */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none p-8"
        animate={{
          rotate: [0, 2, 0, -2, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{
          filter: 'drop-shadow(0 0 40px rgba(0, 255, 255, 0.3))',
        }}
      >
        <img 
          src={mavericksLogo} 
          alt="Mavericks 6.0 Logo" 
          className="w-full h-full object-contain max-w-4xl max-h-screen"
        />
      </motion.div>

      {/* Floating Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-cyan-400 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.3, 1, 0.3],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
          }}
        />
      ))}

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-12">
        <motion.div
          className="text-center space-y-8 max-w-4xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Event Title */}
          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {/* Logo + MAVERICKS Title */}
            <div className="flex items-center justify-center gap-4 md:gap-6 flex-wrap">
              <motion.img
                src={mavericksLogo}
                alt="Mavericks Logo"
                className="w-24 h-24 md:w-32 md:h-32 lg:w-40 lg:h-40 object-contain"
                animate={{
                  filter: [
                    'drop-shadow(0 0 20px rgba(0, 255, 255, 0.5))',
                    'drop-shadow(0 0 30px rgba(0, 255, 255, 0.8))',
                    'drop-shadow(0 0 20px rgba(0, 255, 255, 0.5))',
                  ],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                }}
              />
              <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-wider bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-400 bg-clip-text text-transparent"
                style={{
                  textShadow: '0 0 80px rgba(0, 255, 255, 0.5)',
                }}
              >
                MAVERICKS
              </h1>
            </div>
            <div className="text-5xl md:text-7xl lg:text-8xl font-bold text-red-500"
              style={{
                textShadow: '0 0 40px rgba(239, 68, 68, 0.6)',
              }}
            >
              6.0
            </div>
          </motion.div>

          {/* Subtitle */}
          <motion.p
            className="text-xl md:text-2xl text-cyan-300 tracking-wide"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            A National Level Technical Symposium
          </motion.p>

          {/* College Info */}
          <motion.div
            className="space-y-2 text-gray-300"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <p className="text-lg md:text-xl font-semibold text-white">
              Agni College of Technology
            </p>
            <p className="text-base md:text-lg text-cyan-400">
              Organised by Mechatronics Department
            </p>
          </motion.div>

          {/* Event Description */}
          <motion.div
            className="max-w-2xl mx-auto px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <p className="text-base md:text-lg text-gray-300 leading-relaxed">
              Join us for an extraordinary celebration of innovation and technology. 
              Mavericks 6.0 brings together brilliant minds to compete, collaborate, 
              and showcase cutting-edge solutions to real-world challenges. Experience 
              the future of engineering and push the boundaries of what's possible.
            </p>
          </motion.div>

          {/* Countdown Timer */}
          <motion.div
            className="py-8"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 1 }}
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 max-w-3xl mx-auto">
              {[
                { label: 'DAYS', value: timeLeft.days },
                { label: 'HOURS', value: timeLeft.hours },
                { label: 'MINUTES', value: timeLeft.minutes },
                { label: 'SECONDS', value: timeLeft.seconds },
              ].map((item, index) => (
                <motion.div
                  key={item.label}
                  className="relative"
                  animate={{
                    scale: item.label === 'SECONDS' ? [1, 1.05, 1] : 1,
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                  }}
                >
                  <div className="bg-gradient-to-br from-gray-900 to-black border border-cyan-500/30 rounded-lg p-4 md:p-6 shadow-lg shadow-cyan-500/20">
                    <div className="text-4xl md:text-6xl font-bold bg-gradient-to-b from-cyan-400 to-blue-600 bg-clip-text text-transparent"
                      style={{
                        textShadow: '0 0 30px rgba(0, 255, 255, 0.5)',
                      }}
                    >
                      {String(item.value).padStart(2, '0')}
                    </div>
                    <div className="text-xs md:text-sm text-gray-400 mt-2 tracking-widest">
                      {item.label}
                    </div>
                  </div>
                  {/* Glow effect */}
                  <div className="absolute inset-0 bg-cyan-500/10 rounded-lg blur-xl -z-10" />
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Register Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
          >
            <motion.button
              onClick={() => navigate('/categories')}
              className="relative group px-12 py-4 text-lg md:text-xl font-bold text-white bg-gradient-to-r from-cyan-600 to-blue-600 rounded-full overflow-hidden"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="relative z-10">REGISTER NOW</span>
              
              {/* Animated border */}
              <motion.div
                className="absolute inset-0 rounded-full border-2 border-cyan-400"
                animate={{
                  boxShadow: [
                    '0 0 20px rgba(0, 255, 255, 0.5)',
                    '0 0 40px rgba(0, 255, 255, 0.8)',
                    '0 0 20px rgba(0, 255, 255, 0.5)',
                  ],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                }}
              />
              
              {/* Hover glow */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-400 opacity-0 group-hover:opacity-30 transition-opacity"
              />
            </motion.button>
          </motion.div>
        </motion.div>
      </div>

      {/* Animated Corner Accents */}
      <div className="absolute top-0 left-0 w-32 h-32 border-t-2 border-l-2 border-cyan-500/50" />
      <div className="absolute top-0 right-0 w-32 h-32 border-t-2 border-r-2 border-cyan-500/50" />
      <div className="absolute bottom-0 left-0 w-32 h-32 border-b-2 border-l-2 border-cyan-500/50" />
      <div className="absolute bottom-0 right-0 w-32 h-32 border-b-2 border-r-2 border-cyan-500/50" />
    </div>
  );
}